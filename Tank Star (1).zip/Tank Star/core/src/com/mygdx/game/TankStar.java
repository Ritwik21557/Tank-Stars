package com.mygdx.game;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.mygdx.game.Screens.MainMenu;

import java.io.Serializable;

public class TankStar extends Game implements Serializable {
    public SpriteBatch batch;
//    public MainMenu mainMenu;
    @Override
    public void create() {
        batch = new SpriteBatch();
//        mainMenu =
        setScreen(new MainMenu(this));
    }

    @Override
    public void render() {
        super.render();
    }

    @Override
    public void dispose() {
        super.dispose();
        batch.dispose();
    }
}
