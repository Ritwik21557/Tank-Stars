package com.mygdx.game.Screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TmxMapLoader;
import com.badlogic.gdx.maps.tiled.renderers.OrthogonalTiledMapRenderer;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.mygdx.game.TankStar;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.nio.file.Files;
import java.nio.file.Paths;

public class GamesScreen implements Screen, Serializable {
    private TankStar game;
    private OrthographicCamera camera;
    private Viewport gamePort;
    private TmxMapLoader mapLoader;
    private TiledMap map;
    private OrthogonalTiledMapRenderer renderer;
    private Label vs, playerOneName, playerTwoName, pauseLabel;
    private Texture healthBar, pauseMenu, player1Tank, player2Tank;
    private ImageButton pauseButton;
    private TextButton resumeButton, saveButton;
    private Skin skin;
    private Stage stage1, stage2;
    private boolean paused;
    private int player1TankNum, player2TankNum;
    public GamesScreen(TankStar game, int player1TankNum, int player2TankNum){
        this.game = game;
        paused = false;
        this.player1TankNum = player1TankNum;
        this.player2TankNum = player2TankNum;
        skin = new Skin(Gdx.files.internal("quantum-horizon/skin/quantum-horizon-ui.json"));
        stage1 = new Stage();
        stage2 = new Stage();
        camera = new OrthographicCamera();
        gamePort = new FitViewport(900, 506, camera);
        mapLoader = new TmxMapLoader();
        map = mapLoader.load("untitled02.tmx");
        renderer = new OrthogonalTiledMapRenderer(map);
        camera.position.set(gamePort.getWorldWidth()/2, gamePort.getWorldHeight()/2, 0);
        healthBar = new Texture(Gdx.files.internal("healthBar.png"));
        pauseMenu = new Texture(Gdx.files.internal("pauseMenu.png"));
        vs = new Label("VS", skin, "title");
        pauseLabel = new Label("PAUSED", skin, "default");
        pauseLabel.setPosition(365, 385);
        playerOneName = new Label("Player 1", skin, "title");
        playerTwoName = new Label("Player 2", skin, "title");
        player1Tank = new Texture(Gdx.files.internal("Tanks/tigerTankSmall.png"));
        player2Tank = new Texture(Gdx.files.internal("Tanks/AbramTankSmallFliped.png"));
        vs.setPosition(456, 470);
        playerOneName.setPosition(270, 470);
        playerTwoName.setPosition(570, 470);
        pauseButton = new ImageButton(new TextureRegionDrawable(new Texture("pauseButton.png")));
        pauseButton.setPosition(-10, 420);
        resumeButton = new TextButton("Resume", skin, "default");
        resumeButton.setBounds(335, 275, 275, 60);
        saveButton = new TextButton("Save", skin, "default");
        saveButton.setBounds(335, 180, 275, 60);
        stage1.addActor(vs);
        stage1.addActor(playerOneName);
        stage1.addActor(playerTwoName);
        stage1.addActor(pauseButton);
        stage2.addActor(pauseLabel);
        stage2.addActor(resumeButton);
        stage2.addActor(saveButton);
        Gdx.input.setInputProcessor(stage1);
    }
    public void update(float delta) {
        camera.update();
        renderer.setView(camera);
    }
    @Override
    public void show() {

    }

    @Override
    public void render(float delta) {
        if(paused) {
            Gdx.input.setInputProcessor(stage2);
        }
        update(delta);
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        renderer.render();
        game.batch.setProjectionMatrix(camera.combined);
        game.batch.begin();
        game.batch.draw(healthBar, 165, 430);
        game.batch.draw(player1Tank, 100, 200, 100, 50);
        game.batch.draw(player2Tank, 705, 263, 100, 50);
        game.batch.end();
        stage1.draw();
        if(paused){
            game.batch.begin();
            game.batch.draw(pauseMenu, 275, 0);
            game.batch.end();
            stage2.draw();
        }
        pauseButton.addListener(new ClickListener(){
            @Override
            public void clicked(InputEvent event, float x, float y) {
                paused = true;
            }
        });
        resumeButton.addListener(new ClickListener(){
            @Override
            public void clicked(InputEvent event, float x, float y) {
                paused = false;
                Gdx.input.setInputProcessor(stage1);
            }
        });
        saveButton.addListener(new ClickListener(){
            @Override
            public void clicked(InputEvent event, float x, float y) {
                try {
                    ObjectOutputStream out = new ObjectOutputStream(Files.newOutputStream(Paths.get("gameScreens.txt")));
                    out.writeObject(this);
                    game.setScreen(new MainMenu(game));
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        });
    }

    @Override
    public void resize(int width, int height) {
        gamePort.update(width, height);
    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }}
