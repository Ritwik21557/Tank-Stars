package com.mygdx.game.Screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.mygdx.game.TankStar;

public class resumeScreen implements Screen {
    private TankStar game;
    private Stage stage;
    private Texture backGround, buttons;
    private Label resumeLabel;
    private ImageButton backButton;
    private Skin skin;
    resumeScreen(TankStar game){
        this.game = game;
        skin = new Skin(Gdx.files.internal("quantum-horizon/skin/quantum-horizon-ui.json"));
        backGround = new Texture(Gdx.files.internal("resumeBackground.png"));
        stage = new Stage();
        backButton = new ImageButton(new TextureRegionDrawable(new TextureRegion(new Texture(Gdx.files.internal("backButton.png")))));
        backButton.setBounds(0, 415, 65, 66);
        resumeLabel =  new Label("RESUME", skin, "default");
        resumeLabel.setPosition(350, 450);
        buttons = new Texture(Gdx.files.internal("gameButtons.png"));
        stage.addActor(resumeLabel);
        stage.addActor(backButton);
        Gdx.input.setInputProcessor(stage);
    }
    @Override
    public void show() {

    }

    @Override
    public void render(float delta) {
        game.batch.begin();
        game.batch.draw(backGround, 0, 0);
        game.batch.draw(buttons, 125, 50);
        game.batch.end();
        stage.draw();
        backButton.addListener(new ClickListener(){
            @Override
            public void clicked(InputEvent event, float x, float y) {
                stage.dispose();
                game.setScreen(new MainMenu(game));
            }
        });
    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }
}
