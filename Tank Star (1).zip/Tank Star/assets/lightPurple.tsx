<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="lightPurple" tilewidth="1" tileheight="1" tilecount="2073600" columns="1920">
 <image source="lightPurple.png" width="1920" height="1080"/>
</tileset>
