<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="Hills Layer 02" tilewidth="1" tileheight="1" tilecount="131072" columns="512">
 <image source="Layout/Hills_Layer_02.png" width="512" height="256"/>
</tileset>
