<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="bg" tilewidth="900" tileheight="506" tilecount="1" columns="1">
 <image source="a439b065333621.5af0ea8ca23f5.png" width="900" height="506"/>
</tileset>
